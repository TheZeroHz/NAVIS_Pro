﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shapes;

namespace NavisPCAPP
{
    public partial class MainWindow : Window
    {
        // Whiteboard-related fields
        private Window? whiteboardWindow;

        public MainWindow()
        {
            InitializeComponent();

            // Make sure the window can receive focus and key events
            this.Focusable = true;
            this.KeyDown += MainWindow_KeyDown;
            this.Activated += (s, e) => this.Focus();
            this.Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            this.Focus();
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            HandleKeyPress(e.Key);
        }

        private void MainWindow_KeyDown(object sender, KeyEventArgs e)
        {
            HandleKeyPress(e.Key);
        }

        private void HandleKeyPress(Key key)
        {
            switch (key)
            {
                case Key.F4:
                    OpenWhiteboard();
                    break;
            }
        }

        private void OpenWhiteboard()
        {
            if (whiteboardWindow == null || !whiteboardWindow.IsLoaded)
            {
                whiteboardWindow = new WhiteboardWindow();
                whiteboardWindow.Closed += (s, e) => whiteboardWindow = null;
            }

            whiteboardWindow.Show();
            whiteboardWindow.Activate();
            whiteboardWindow.WindowState = WindowState.Normal;
        }

        private void OpenWhiteboardButton_Click(object sender, RoutedEventArgs e)
        {
            OpenWhiteboard();
        }

        protected override void OnClosed(EventArgs e)
        {
            whiteboardWindow?.Close();
            base.OnClosed(e);
        }
    }

    // Beautiful Professional Whiteboard Window Implementation
    public partial class WhiteboardWindow : Window
    {
        private InkCanvas drawingCanvas = null!;
        private bool isEraserMode = false;
        private bool isBlackBoard = false;
        private double penSize = 4;
        private Color currentColor = Colors.Red;
        private Color[] colorPalette = {
            Colors.Red, Colors.Blue, Colors.Green, Colors.Yellow,
            Colors.Purple, Colors.Orange, Colors.Pink, Colors.Brown,
            Colors.Black, Colors.White, Colors.Cyan, Colors.Magenta
        };
        private int currentColorIndex = 0;

        // UI Elements for easy access
        private Button penButton = null!;
        private Button eraserButton = null!;
        private Button colorButton = null!;
        private TextBlock sizeText = null!;
        private Button boardToggle = null!;

        public WhiteboardWindow()
        {
            InitializeWhiteboardWindow();

            // Global key handling - this ensures ESC works from anywhere
            this.KeyDown += WhiteboardWindow_KeyDown;
            this.PreviewKeyDown += WhiteboardWindow_PreviewKeyDown;

            // Focus handling
            this.Loaded += (s, e) => this.Focus();
            this.Activated += (s, e) => this.Focus();
        }

        private void InitializeWhiteboardWindow()
        {
            Title = "Navis Pro - Digital Whiteboard";
            Width = 1200;
            Height = 800;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            Background = new SolidColorBrush(Color.FromRgb(26, 26, 26));

            // Allow ESC to be captured globally
            this.Focusable = true;

            var mainGrid = new Grid();
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(80) });
            mainGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // Beautiful Toolbar
            var toolbar = CreateBeautifulToolbar();
            Grid.SetRow(toolbar, 0);

            // Drawing Canvas with modern styling
            var canvasBorder = new Border
            {
                Background = Brushes.White,
                CornerRadius = new CornerRadius(12),
                BorderBrush = new SolidColorBrush(Color.FromRgb(64, 64, 64)),
                BorderThickness = new Thickness(2),
                Margin = new Thickness(15, 10, 15, 15),
                Effect = new DropShadowEffect
                {
                    Color = Colors.Black,
                    ShadowDepth = 4,
                    BlurRadius = 15,
                    Opacity = 0.3
                }
            };

            drawingCanvas = new InkCanvas
            {
                Background = Brushes.White,
                UseCustomCursor = true,
                Focusable = true
            };

            // Set up initial drawing attributes
            var drawingAttributes = new System.Windows.Ink.DrawingAttributes
            {
                Color = currentColor,
                Width = penSize,
                Height = penSize,
                StylusTip = System.Windows.Ink.StylusTip.Ellipse,
                IsHighlighter = false
            };

            drawingCanvas.DefaultDrawingAttributes = drawingAttributes;
            drawingCanvas.EditingMode = InkCanvasEditingMode.Ink;

            // Ensure drawing canvas can also handle ESC
            drawingCanvas.KeyDown += WhiteboardWindow_KeyDown;
            drawingCanvas.PreviewKeyDown += WhiteboardWindow_PreviewKeyDown;

            canvasBorder.Child = drawingCanvas;
            Grid.SetRow(canvasBorder, 1);

            mainGrid.Children.Add(toolbar);
            mainGrid.Children.Add(canvasBorder);

            Content = mainGrid;
        }

        private Border CreateBeautifulToolbar()
        {
            var toolbar = new Border
            {
                Background = new LinearGradientBrush(
                    Color.FromRgb(45, 45, 45),
                    Color.FromRgb(35, 35, 35),
                    90),
                CornerRadius = new CornerRadius(0, 0, 12, 12),
                Effect = new DropShadowEffect
                {
                    Color = Colors.Black,
                    ShadowDepth = 2,
                    BlurRadius = 8,
                    Opacity = 0.3
                }
            };

            var toolGrid = new Grid
            {
                Margin = new Thickness(20, 10, 20, 10)
            };

            toolGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            toolGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            toolGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            // Left section - Tools
            var leftStack = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Center
            };

            // Board Type Toggle
            boardToggle = CreateModernToolButton("🌙", "Toggle Board Type (Ctrl+B)");
            boardToggle.Click += BoardToggle_Click;
            leftStack.Children.Add(boardToggle);

            leftStack.Children.Add(CreateSeparator());

            // Pen Tool
            penButton = CreateModernToolButton("✏️", "Pen Tool (Ctrl+P)");
            penButton.Background = new SolidColorBrush(Color.FromRgb(59, 130, 246));
            penButton.Click += PenTool_Click;
            leftStack.Children.Add(penButton);

            // Eraser Tool
            eraserButton = CreateModernToolButton("🧹", "Eraser Tool (Ctrl+E)");
            eraserButton.Click += EraserTool_Click;
            leftStack.Children.Add(eraserButton);

            Grid.SetColumn(leftStack, 0);
            toolGrid.Children.Add(leftStack);

            // Center section - Size and Color
            var centerStack = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };

            // Size controls
            var sizeLabel = new TextBlock
            {
                Text = "Size:",
                Foreground = Brushes.White,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 8, 0),
                FontWeight = FontWeights.Medium
            };
            centerStack.Children.Add(sizeLabel);

            var sizeSlider = new Slider
            {
                Width = 120,
                Minimum = 2,
                Maximum = 25,
                Value = penSize,
                VerticalAlignment = VerticalAlignment.Center,
                Style = CreateModernSliderStyle()
            };
            sizeSlider.ValueChanged += SizeSlider_ValueChanged;
            centerStack.Children.Add(sizeSlider);

            sizeText = new TextBlock
            {
                Text = penSize.ToString("F0"),
                Foreground = Brushes.White,
                VerticalAlignment = VerticalAlignment.Center,
                Width = 25,
                Margin = new Thickness(8, 0, 15, 0),
                FontWeight = FontWeights.Bold
            };
            centerStack.Children.Add(sizeText);

            // Color picker
            colorButton = new Button
            {
                Content = "🎨",
                Width = 50,
                Height = 50,
                Background = new SolidColorBrush(currentColor),
                ToolTip = "Click to change color",
                Margin = new Thickness(5),
                Style = CreateColorButtonStyle()
            };
            colorButton.Click += ColorButton_Click;
            centerStack.Children.Add(colorButton);

            Grid.SetColumn(centerStack, 1);
            toolGrid.Children.Add(centerStack);

            // Right section - Actions
            var rightStack = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Center
            };

            // Clear button
            var clearButton = CreateModernToolButton("🗑️", "Clear All (Ctrl+C)");
            clearButton.Background = new SolidColorBrush(Color.FromRgb(239, 68, 68));
            clearButton.Click += ClearButton_Click;
            rightStack.Children.Add(clearButton);

            rightStack.Children.Add(CreateSeparator());

            // Fullscreen button
            var fullscreenButton = CreateModernToolButton("⛶", "Fullscreen (F11)");
            fullscreenButton.Background = new SolidColorBrush(Color.FromRgb(16, 185, 129));
            fullscreenButton.Click += (s, e) => ToggleFullscreen();
            rightStack.Children.Add(fullscreenButton);

            // Close button
            var closeButton = CreateModernToolButton("✕", "Close (ESC)");
            closeButton.Background = new SolidColorBrush(Color.FromRgb(156, 163, 175));
            closeButton.Click += CloseButton_Click;
            rightStack.Children.Add(closeButton);

            Grid.SetColumn(rightStack, 2);
            toolGrid.Children.Add(rightStack);

            toolbar.Child = toolGrid;
            return toolbar;
        }

        private Button CreateModernToolButton(string content, string tooltip)
        {
            var button = new Button
            {
                Content = content,
                Width = 50,
                Height = 50,
                Margin = new Thickness(3),
                ToolTip = tooltip,
                FontSize = 18,
                Cursor = Cursors.Hand,
                Style = CreateModernButtonStyle()
            };

            return button;
        }

        private Style CreateModernButtonStyle()
        {
            var style = new Style(typeof(Button));

            style.Setters.Add(new Setter(Button.BackgroundProperty, new SolidColorBrush(Color.FromRgb(75, 85, 99))));
            style.Setters.Add(new Setter(Button.ForegroundProperty, Brushes.White));
            style.Setters.Add(new Setter(Button.BorderThicknessProperty, new Thickness(0)));
            style.Setters.Add(new Setter(Button.FontWeightProperty, FontWeights.Bold));

            var template = new ControlTemplate(typeof(Button));
            var borderFactory = new FrameworkElementFactory(typeof(Border));
            borderFactory.SetBinding(Border.BackgroundProperty, new System.Windows.Data.Binding("Background") { RelativeSource = new System.Windows.Data.RelativeSource(System.Windows.Data.RelativeSourceMode.TemplatedParent) });
            borderFactory.SetValue(Border.CornerRadiusProperty, new CornerRadius(8));

            var contentFactory = new FrameworkElementFactory(typeof(ContentPresenter));
            contentFactory.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
            contentFactory.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);

            borderFactory.AppendChild(contentFactory);
            template.VisualTree = borderFactory;

            // Add triggers for hover and pressed states
            var hoverTrigger = new Trigger { Property = Button.IsMouseOverProperty, Value = true };
            hoverTrigger.Setters.Add(new Setter(Button.OpacityProperty, 0.8));
            template.Triggers.Add(hoverTrigger);

            var pressedTrigger = new Trigger { Property = Button.IsPressedProperty, Value = true };
            pressedTrigger.Setters.Add(new Setter(Button.OpacityProperty, 0.6));
            template.Triggers.Add(pressedTrigger);

            style.Setters.Add(new Setter(Button.TemplateProperty, template));

            return style;
        }

        private Style CreateColorButtonStyle()
        {
            var style = CreateModernButtonStyle();
            style.Setters.Add(new Setter(Button.BorderThicknessProperty, new Thickness(3)));
            style.Setters.Add(new Setter(Button.BorderBrushProperty, Brushes.White));
            return style;
        }

        private Style CreateModernSliderStyle()
        {
            var style = new Style(typeof(Slider));
            style.Setters.Add(new Setter(Slider.ForegroundProperty, new SolidColorBrush(Color.FromRgb(59, 130, 246))));
            return style;
        }

        private Rectangle CreateSeparator()
        {
            return new Rectangle
            {
                Width = 1,
                Height = 35,
                Fill = new SolidColorBrush(Color.FromRgb(107, 114, 128)),
                Margin = new Thickness(8, 0, 8, 0)
            };
        }

        private void ToggleFullscreen()
        {
            WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        }

        // Event Handlers
        private void BoardToggle_Click(object sender, RoutedEventArgs e)
        {
            isBlackBoard = !isBlackBoard;

            if (isBlackBoard)
            {
                drawingCanvas.Background = new SolidColorBrush(Color.FromRgb(30, 30, 30));
                boardToggle.Content = "☀️";
                boardToggle.ToolTip = "Switch to Light Mode (Ctrl+B)";

                // Switch to white pen if current color is too dark
                if (currentColor == Colors.Black || (currentColor.R + currentColor.G + currentColor.B < 200 && currentColor != Colors.White))
                {
                    currentColor = Colors.White;
                    UpdatePenAttributes();
                }
            }
            else
            {
                drawingCanvas.Background = Brushes.White;
                boardToggle.Content = "🌙";
                boardToggle.ToolTip = "Switch to Dark Mode (Ctrl+B)";

                // Switch to black pen if current color is white
                if (currentColor == Colors.White)
                {
                    currentColor = Colors.Black;
                    UpdatePenAttributes();
                }
            }
        }

        private void PenTool_Click(object sender, RoutedEventArgs e)
        {
            drawingCanvas.EditingMode = InkCanvasEditingMode.Ink;
            isEraserMode = false;

            penButton.Background = new SolidColorBrush(Color.FromRgb(59, 130, 246));
            eraserButton.Background = new SolidColorBrush(Color.FromRgb(75, 85, 99));
        }

        private void EraserTool_Click(object sender, RoutedEventArgs e)
        {
            drawingCanvas.EditingMode = InkCanvasEditingMode.EraseByStroke;
            isEraserMode = true;

            eraserButton.Background = new SolidColorBrush(Color.FromRgb(245, 101, 101));
            penButton.Background = new SolidColorBrush(Color.FromRgb(75, 85, 99));
        }

        private void SizeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            penSize = e.NewValue;
            UpdatePenAttributes();

            if (sizeText != null)
            {
                sizeText.Text = penSize.ToString("F0");
            }
        }

        private void ColorButton_Click(object sender, RoutedEventArgs e)
        {
            currentColorIndex = (currentColorIndex + 1) % colorPalette.Length;
            currentColor = colorPalette[currentColorIndex];

            colorButton.Background = new SolidColorBrush(currentColor);
            UpdatePenAttributes();
        }

        private void UpdatePenAttributes()
        {
            if (drawingCanvas?.DefaultDrawingAttributes != null)
            {
                drawingCanvas.DefaultDrawingAttributes.Color = currentColor;
                drawingCanvas.DefaultDrawingAttributes.Width = penSize;
                drawingCanvas.DefaultDrawingAttributes.Height = penSize;

                if (colorButton != null)
                {
                    colorButton.Background = new SolidColorBrush(currentColor);
                }
            }
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show(
                "Are you sure you want to clear all drawings?\n\nThis action cannot be undone.",
                "Confirm Clear",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                drawingCanvas.Strokes.Clear();
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        // Global key handling - ensures ESC works from anywhere in the window
        private void WhiteboardWindow_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                Close();
                e.Handled = true;
            }
        }

        private void WhiteboardWindow_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Escape:
                    Close();
                    e.Handled = true;
                    break;

                case Key.P:
                    if (Keyboard.Modifiers == ModifierKeys.Control)
                    {
                        PenTool_Click(penButton, new RoutedEventArgs());
                        e.Handled = true;
                    }
                    break;

                case Key.E:
                    if (Keyboard.Modifiers == ModifierKeys.Control)
                    {
                        EraserTool_Click(eraserButton, new RoutedEventArgs());
                        e.Handled = true;
                    }
                    break;

                case Key.C:
                    if (Keyboard.Modifiers == ModifierKeys.Control)
                    {
                        ClearButton_Click(sender, new RoutedEventArgs());
                        e.Handled = true;
                    }
                    break;

                case Key.B:
                    if (Keyboard.Modifiers == ModifierKeys.Control)
                    {
                        BoardToggle_Click(boardToggle, new RoutedEventArgs());
                        e.Handled = true;
                    }
                    break;

                case Key.F11:
                    ToggleFullscreen();
                    e.Handled = true;
                    break;
            }
        }

        // Override to ensure ESC always closes the window
        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                Close();
                e.Handled = true;
                return;
            }

            base.OnKeyDown(e);
        }

        // Additional safety measure - handle at window level
        protected override void OnPreviewKeyDown(KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                Close();
                e.Handled = true;
                return;
            }

            base.OnPreviewKeyDown(e);
        }
    }
}